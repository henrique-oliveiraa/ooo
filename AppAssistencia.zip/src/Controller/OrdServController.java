package Controller;

import DAL.OperTesteOrdemServ;
import Model.ClienteModel;
import Model.OrdServModel;
import java.util.ArrayList;

public class OrdServController {

    public ArrayList<ClienteModel> pesquisarPorIDController(String idClient) {
        OrdServModel op = new OrdServModel();
        return op.pesquisarPorIDModel(idClient);
    }
    
    public ArrayList<OrdServModel> pesquisarOrdServPorIDController(String idOrdServ){
        OrdServModel op = new OrdServModel();
        return op.pesquisarPorIDOrdServ(idOrdServ);
    
    }

    public void ordServController(String idCli, String equipamento, String defeito) {

        // Instanciar o objeto - model
        OrdServModel novaOrdServ = new OrdServModel(idCli, equipamento, defeito);
        OrdServModel op = new OrdServModel();
        op.inserirRegistrosModel(novaOrdServ);

    }

}
